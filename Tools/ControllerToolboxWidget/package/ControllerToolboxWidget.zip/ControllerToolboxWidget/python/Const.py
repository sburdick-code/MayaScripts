import os

class Const:
    WORKING_DIR = os.path.dirname(os.path.dirname(__file__))
    CTRL_DATA_DIR = WORKING_DIR + "\\controller_data\\"
    UI_DIR = WORKING_DIR + "\\ui\\"
    TEMP_IMAGE_PATH = WORKING_DIR + "\\controller_data\\tempCapture.png"
