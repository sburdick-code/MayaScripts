Controller Toolbox is a rigging utility tool that allows artists to quickly and efficiently, save, manipulate, and edit control curves in maya.

How to Install
1) Unzip the zip file.
2) Drag and drop the install.py file into the maya viewport
3) A new shelf button will be created on the shelf you currently have open